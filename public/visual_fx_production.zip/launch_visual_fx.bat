@echo off
title Visual-FX - Transmisiones Hipicas Fenix
echo ====================================================
echo    INICIANDO PLATAFORMA VISUAL-FX (AGENCIAS FENIX)
echo ====================================================
echo.
cd /d "%~dp0"
start "" http://localhost:3500
cmd /c node server.js
pause
