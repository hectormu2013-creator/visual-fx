const fetch = require('node-fetch');

async function testAll() {
  console.log('--- 1. Testing Channels API ---');
  const chRes = await fetch('http://localhost:3500/api/channels');
  const chData = await chRes.json();
  console.log('Channels Total:', chData.total);

  console.log('\n--- 2. Testing Auth Login (leo1 / 1234) ---');
  const loginRes = await fetch('http://localhost:3500/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'leo1', password: '1234' })
  });
  const loginData = await loginRes.json();
  console.log('Login Success:', loginData.success, '| User:', loginData.user?.name);

  console.log('\n--- 3. Testing Approved Device Verification (TV-CABIMAS-01) ---');
  const devRes = await fetch('http://localhost:3500/api/device/verify?deviceId=TV-CABIMAS-01');
  const devData = await devRes.json();
  console.log('Device Status:', devData.status, '| TV Name:', devData.device?.tvName);

  console.log('\n--- 4. Testing Unauthorized Device Verification (TV-NEW-99) ---');
  const devUnres = await fetch('http://localhost:3500/api/device/verify?deviceId=TV-NEW-99');
  const devUnData = await devUnres.json();
  console.log('Device Status:', devUnData.status, '| Activation PIN:', devUnData.pin);

  console.log('\n--- 5. Testing Device Activation with PIN ---');
  const actRes = await fetch('http://localhost:3500/api/admin/authorize-device', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ pin: devUnData.pin, tvName: 'TV-Sede Cabimas #2', agencyId: 'CAB-01' })
  });
  const actData = await actRes.json();
  console.log('Activation Success:', actData.success, '| Device ID:', actData.deviceId);

  console.log('\n--- 6. Re-verifying Previously Unauthorized Device ---');
  const reDevRes = await fetch('http://localhost:3500/api/device/verify?deviceId=TV-NEW-99');
  const reDevData = await reDevRes.json();
  console.log('Updated Status:', reDevData.status, '| TV Name:', reDevData.device?.tvName);

  console.log('\n✅ ALL VISUAL-FX BACKEND & LICENSING TESTS PASSED!');
}

testAll().catch(console.error);
