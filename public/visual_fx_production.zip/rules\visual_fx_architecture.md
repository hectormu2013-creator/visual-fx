# Directrices de Arquitectura para Sistemas de Streaming y Gestión de Agencias (Visual-FX)

## 1. Patrón de Relay Máster y Proxy HLS
- **Propósito**: Eliminar cobros por dispositivo/pantalla en servicios de video IPTV ($7/TV).
- **Regla**: Cuando se construyan paneles o clientes para múltiples pantallas de agencias, el backend debe actuar como un **Proxy e Ingestor Máster Centralizado** (`stream_proxy.js` / `master_ingest.js`).
- **Implementación**:
  - Reescribir listas de reproducción HLS (`.m3u8`) sustituyendo las URLs relativas de los fragmentos `.ts` por endpoints internos `/api/stream/proxy?url=...`.
  - Servir las transmisiones a ilimitados receptores sin multiplicar los costos ni disparar bloqueos por consumo multi-dispositivo upstream.

## 2. Control de Acceso Jerárquico (RBAC) y Seguridad por Dispositivo
- **Estructura Obligatoria de Roles**:
  - `SUPER_ADMIN`: Propietario / Gerencia. Acceso total a usuarios, sedes, finanzas, señales máster y revocación de pantallas.
  - `TECH_CHIEF`: Jefe de Soporte Técnico. Gestión de fallas de transmisión, cambio de URLs máster en caliente y asistencia multisede.
  - `AGENCY_MANAGER`: Encargado de Sede Local. Visualización de señales locales y activación de pantallas de su sede vía PIN de 6 dígitos (`FX-XXXX`).

## 3. Portales Administrativos Ejecutivos por Pestañas
- **Regla UI**: Nunca amontonar múltiples tareas de administración complejas en una sola ventana vertical con scroll.
- **Diseño**: Utilizar **Navegación por Pestañas Independientes** (*Televisores*, *Señales Máster*, *Usuarios y Agencias*) con ancho adecuado (`900px`+), tablas de datos con divisores claros e insignias de estado neumórficas.
