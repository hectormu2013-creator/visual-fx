const fetch = require('node-fetch');

async function inspectGringasHD() {
  const pages = [
    'https://gringashd.com/inhlarinconada3.php',
    'https://gringashd.com/meridianotv.php',
    'https://gringashd.com/usa1.php',
    'https://gringashd.com/usa2.php',
    'https://gringashd.com/usa3.php',
    'https://gringashd.com/usa4.php',
    'https://gringashd.com/gulfstream.php',
    'https://gringashd.com/saratoga.php'
  ];

  for (const pageUrl of pages) {
    try {
      const res = await fetch(pageUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Referer': 'https://www.granvideohd.com/'
        }
      });

      console.log(`\n====================================================`);
      console.log(`🔎 Target: ${pageUrl} (Status: ${res.status})`);
      const html = await res.text();
      console.log(html.substring(0, 1000));
      console.log(`====================================================`);
    } catch (e) {
      console.log(`❌ Error fetching ${pageUrl}: ${e.message}`);
    }
  }
}

inspectGringasHD().catch(console.error);
