const puppeteer = require('puppeteer');
const fs = require('fs');

async function extractStreams() {
  console.log('🚀 Iniciando navegador Puppeteer para GranVideoHD...');
  const browser = await puppeteer.launch({
    headless: false, // Modo visible para observar el login si es necesario
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 800 });

  const capturedStreams = [];

  // Escuchar todas las peticiones de red para capturar transmisiones m3u8 / ts / iFrames / WebSocket
  page.on('request', request => {
    const url = request.url();
    if (url.includes('.m3u8') || url.includes('.m4s') || url.includes('stream') || url.includes('live') || url.includes('hls') || url.includes('embed')) {
      console.log('🎥 SEÑAL DETECTADA:', url);
      capturedStreams.push({ url, method: request.method(), headers: request.headers() });
    }
  });

  console.log('🌐 Navegando a https://www.granvideohd.com/cl/accesoooo.php...');
  await page.goto('https://www.granvideohd.com/cl/accesoooo.php', { waitUntil: 'networkidle2' });

  // Tomar captura inicial
  await page.screenshot({ path: 'login_granvideo.png' });
  console.log('📸 Captura de login guardada como login_granvideo.png');

  // Llenar campos de usuario y clave
  console.log('🔑 Introduciendo credenciales leo1 / 1234...');
  await page.type('input[name="usuario"]', 'leo1');
  await page.type('input[name="clave"]', '1234');

  // Hacer clic en Iniciar sesión
  console.log('🔘 Haciendo clic en Iniciar Sesión...');
  await Promise.all([
    page.click('#enviar_form'),
    page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(e => console.log('Navegación tras login:', e.message))
  ]);

  await new Promise(r => setTimeout(r, 3000));

  // Tomar captura tras enviar formulario
  await page.screenshot({ path: 'after_login_granvideo.png' });
  console.log('📸 Captura guardada como after_login_granvideo.png');
  console.log('📍 URL Actual:', page.url());

  // Verificar si hay campo de respuesta de seguridad "Cabimas"
  const securityInput = await page.$('input[name="respuesta"], input[name="pregunta"], #respuesta_seguridad');
  if (securityInput) {
    console.log('🔒 Campo de seguridad detectado. Introduciendo "Cabimas"...');
    await securityInput.type('Cabimas');
    const submitBtn = await page.$('button[type="submit"], input[type="submit"]');
    if (submitBtn) {
      await Promise.all([
        submitBtn.click(),
        page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(e => {})
      ]);
    }
    await new Promise(r => setTimeout(r, 3000));
    await page.screenshot({ path: 'after_security_granvideo.png' });
  }

  // Extraer el HTML final y todos los iFrames / elementos de video de la página
  const pageHtml = await page.content();
  fs.writeFileSync('dashboard_granvideo.html', pageHtml);
  console.log('📄 HTML de la página guardado en dashboard_granvideo.html');

  // Extraer enlaces de iframe o reproductores
  const videoElements = await page.evaluate(() => {
    const iframes = Array.from(document.querySelectorAll('iframe')).map(i => i.src);
    const videos = Array.from(document.querySelectorAll('video, embed, object')).map(v => v.src || v.querySelector('source')?.src);
    const links = Array.from(document.querySelectorAll('a')).map(a => ({ text: a.innerText.trim(), href: a.href }));
    return { iframes, videos, links };
  });

  console.log('\n====================================================');
  console.log('📺 REPRODUCTORES E IFRAMES ENCONTRADOS:');
  console.log(JSON.stringify(videoElements, null, 2));
  console.log('====================================================\n');

  console.log('🎥 SEÑALES HLS/M3U8 CAPTURADAS:', capturedStreams.length);
  fs.writeFileSync('captured_streams.json', JSON.stringify(capturedStreams, null, 2));

  await browser.close();
}

extractStreams().catch(console.error);
