const puppeteer = require('puppeteer');
const fs = require('fs');

async function getLiveStreams() {
  console.log('🚀 1. Iniciando Chrome...');
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  console.log('🌐 2. Entrando a https://www.granvideohd.com/cl/accesoooo.php...');
  await page.goto('https://www.granvideohd.com/cl/accesoooo.php', { waitUntil: 'networkidle2' });

  // Llenar formulario
  console.log('🔑 3. Llenando datos (leo1 / 1234)...');
  await page.waitForSelector('input[name="usuario"]');
  await page.type('input[name="usuario"]', 'leo1');
  await page.type('input[name="clave"]', '1234');
  
  console.log('🔘 4. Presionando Iniciar Sesión y esperando redirección...');
  await page.click('#enviar_form');

  let handledSecurity = false;
  for (let i = 0; i < 15; i++) {
    await new Promise(r => setTimeout(r, 1000));
    const currentUrl = page.url();
    console.log(`Paso ${i+1}/15 - URL Actual: ${currentUrl}`);
    
    if (currentUrl.includes('responder.php') && !handledSecurity) {
      handledSecurity = true;
      console.log('🔒 Detectado responder.php. Enviando respuesta "Cabimas"...');
      try {
        const respInput = await page.waitForSelector('input[name="respuesta"], #respuesta', { timeout: 3000 });
        if (respInput) {
          await respInput.type('Cabimas');
          await page.waitForTimeout(500);
          const submitBtn = await page.$('button[type="submit"], input[type="submit"], #enviar, #enviar_form');
          if (submitBtn) await submitBtn.click();
          else await page.keyboard.press('Enter');
        }
      } catch(e) {
        console.error('Error al responder seguridad:', e.message);
      }
    }

    if (currentUrl === 'https://www.granvideohd.com/' || currentUrl.includes('index.php') || currentUrl.includes('principal.php') || currentUrl.includes('canal')) {
      console.log('🎯 ¡Redirección completada a la página principal!');
      break;
    }
  }

  const cookies = await page.cookies();
  console.log('🍪 Cookies de Sesión:', cookies.map(c => `${c.name}=${c.value}`).join('; '));

  console.log('\n--- 5. Consultando Canales de GranVideoHD ---');
  const results = await page.evaluate(async () => {
    const output = [];
    const channels = [
      { sala: 1, canal: 1, name: 'Canal 1' },
      { sala: 1, canal: 2, name: 'Canal 2' },
      { sala: 1, canal: 3, name: 'Canal 3' },
      { sala: 1, canal: 4, name: 'Canal 4' },
      { sala: 2, canal: 1, name: 'Sala 2 Canal 1' },
      { sala: 2, canal: 2, name: 'Sala 2 Canal 2' }
    ];

    for (const c of channels) {
      try {
        const formData = new URLSearchParams();
        formData.append('accion', 'actualizar_player1');
        formData.append('sala', c.sala);
        formData.append('canal', c.canal);

        const res = await fetch('/sv/consultas_canales.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: formData.toString()
        });

        const text = await res.text();
        let data = null;
        try {
          data = JSON.parse(text);
        } catch (e) {
          data = { rawText: text.substring(0, 300) };
        }
        output.push({ channel: c, data });
      } catch (err) {
        output.push({ channel: c, error: err.message });
      }
    }
    return output;
  });

  console.log('====================================================');
  console.log('📺 RESPUESTA DE SEÑALES EXTRAÍDAS:');
  console.log(JSON.stringify(results, null, 2));
  console.log('====================================================');

  fs.writeFileSync('granvideo_extracted_channels.json', JSON.stringify(results, null, 2));

  await browser.close();
}

getLiveStreams().catch(console.error);
