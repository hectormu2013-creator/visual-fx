const fetch = require('node-fetch');

async function loginGranVideo() {
  console.log('--- 1. Requesting Login Page ---');
  const initialRes = await fetch('https://www.granvideohd.com/cl/accesoooo.php', {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
  });

  const cookies = initialRes.headers.raw()['set-cookie'] || [];
  const cookieHeader = cookies.map(c => c.split(';')[0]).join('; ');
  console.log('Received Cookies:', cookieHeader);

  console.log('\n--- 2. Submitting Credentials (leo1 / 1234) ---');
  
  // Probamos los endpoints comunes de validación PHP
  const endpoints = [
    'https://www.granvideohd.com/cl/validar.php',
    'https://www.granvideohd.com/cl/acceso_valida.php',
    'https://www.granvideohd.com/cl/login.php',
    'https://www.granvideohd.com/cl/admin_acceso.php'
  ];

  for (const endpoint of endpoints) {
    try {
      const params = new URLSearchParams();
      params.append('usuario', 'leo1');
      params.append('clave', '1234');
      params.append('respuesta', 'Cabimas');

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Cookie': cookieHeader,
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: params
      });

      console.log(`Endpoint [${endpoint}] -> Status: ${res.status}`);
      const text = await res.text();
      if (res.status === 200 && text.length < 500) {
        console.log('Response body:', text);
      }
    } catch (e) {
      console.log(`Endpoint [${endpoint}] -> Error: ${e.message}`);
    }
  }
}

loginGranVideo().catch(console.error);
