const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const projectDir = __dirname;
const zipPath = path.join(__dirname, '..', 'visual_fx_production.zip');

try {
  if (fs.existsSync(zipPath)) {
    fs.unlinkSync(zipPath);
  }
  const psCmd = `powershell -Command "Get-ChildItem -Path '${projectDir}\\*' -Exclude 'node_modules','*.log','*.png' | Compress-Archive -DestinationPath '${zipPath}'"`;
  console.log('Creando archivo de despliegue zip...');
  execSync(psCmd);
  console.log(`✅ Archivo Zip de Producción creado en: ${zipPath}`);
} catch (err) {
  console.error('Error creando zip:', err.message);
}
