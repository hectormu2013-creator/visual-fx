const fetch = require('node-fetch');
const fs = require('fs');

async function createRepo() {
  console.log('🚀 Creando repositorio público para despliegue en Render...');
  
  // Usamos la API de GitLab para crear un repositorio público instantáneo
  const res = await fetch('https://gitlab.com/api/v4/projects', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: `visual-fx-${Date.now()}`,
      visibility: 'public',
      description: 'Visual-FX Horse Racing Platform for Fenix Agencies'
    })
  });

  const data = await res.json();
  console.log('GitLab Response:', data);
}

createRepo().catch(console.error);
