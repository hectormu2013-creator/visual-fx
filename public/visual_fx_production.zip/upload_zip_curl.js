const { execSync } = require('child_process');
const path = require('path');

const zipPath = path.join(__dirname, '..', 'visual_fx_production.zip');

try {
  console.log('Subiendo paquete comprimido a tmpfiles.org vía curl...');
  const res = execSync(`curl -s -F "file=@${zipPath}" https://tmpfiles.org/api/v1/upload`).toString();
  const data = JSON.parse(res);
  if (data && data.data && data.data.url) {
    const directUrl = data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
    console.log('====================================================');
    console.log('✅ URL DE DESCARGA DIRECTA DE PRODUCCIÓN:');
    console.log(directUrl);
    console.log('====================================================');
  } else {
    console.log('Respuesta:', res);
  }
} catch (e) {
  console.error('Error:', e.message);
}
