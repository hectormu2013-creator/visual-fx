const fetch = require('node-fetch');

// Credenciales GranVideoHD para Puente Temporada
const GRANVIDEO_CREDS = {
  url: 'https://www.granvideohd.com/cl/accesoooo.php',
  user: 'leo1',
  pass: '1234',
  resp: 'Cabimas'
};

// Mapeo de Hipódromos Visual-FX a Salas GranVideoHD
const GRANVIDEO_CHANNEL_MAP = {
  'belmont-park': { sala: 1, canal: 1 },
  'colonial-downs': { sala: 1, canal: 2 },
  'del-mar': { sala: 1, canal: 3 },
  'delaware-park': { sala: 1, canal: 4 },
  'finger-lakes': { sala: 1, canal: 5 },
  'gulfstream-park': { sala: 1, canal: 6 },
  'horseshoe-indianapolis': { sala: 1, canal: 7 },
  'laurel-park': { sala: 1, canal: 8 },
  'monmouth-park': { sala: 1, canal: 9 },
  'santa-anita-park': { sala: 1, canal: 10 },
  'saratoga': { sala: 1, canal: 11 },
  'thistledown': { sala: 1, canal: 12 },
  'woodbine': { sala: 1, canal: 13 }
};

async function fetchGranVideoLiveStreams() {
  console.log('📡 [Puente GranVideoHD] Conectando a la fuente máster temporary para Agencias Fenix...');
  const activeStreams = {};

  for (const [channelId, pos] of Object.entries(GRANVIDEO_CHANNEL_MAP)) {
    try {
      const res = await fetch('https://www.granvideohd.com/sv/consultas_canales.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `accion=actualizar_player1&sala=${pos.sala}&canal=${pos.canal}`
      });
      const data = await res.json();
      
      if (data && (data.src_iframe || data.url || data.iframe)) {
        let streamUrl = data.src_iframe || data.url;
        if (!streamUrl && data.iframe) {
          const match = data.iframe.match(/src=["']([^"']+)["']/i);
          if (match) streamUrl = match[1];
        }

        if (streamUrl) {
          activeStreams[channelId] = {
            streamUrl,
            type: streamUrl.includes('.m3u8') ? 'hls' : 'iframe'
          };
          console.log(`✅ [Puente] Señal obtenida para ${channelId}: ${streamUrl}`);
        }
      }
    } catch (e) {
      console.log(`⚠️ [Puente] Sin transmisión activa por el momento en ${channelId}`);
    }
  }

  return activeStreams;
}

module.exports = {
  fetchGranVideoLiveStreams
};
