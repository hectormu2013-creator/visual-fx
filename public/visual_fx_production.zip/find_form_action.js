const fetch = require('node-fetch');

async function findAction() {
  const res = await fetch('https://www.granvideohd.com/cl/accesoooo.php');
  const html = await res.text();
  console.log('HTML Length:', html.length);

  // Search for form action or AJAX endpoints in HTML
  const formMatch = html.match(/<form[^>]*>/gi);
  console.log('Form tags:', formMatch);

  const scripts = html.match(/src=["']([^"']+)["']/gi);
  console.log('Scripts:', scripts);
}

findAction();
