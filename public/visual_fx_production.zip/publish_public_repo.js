const fetch = require('node-fetch');

async function checkPublicRepo() {
  // Probamos repositorios de plantillas Node de Render compatibles
  const testUrl = 'https://github.com/render-examples/express-hello-world';
  console.log('Probando validez del repo:', testUrl);
}

checkPublicRepo();
