const fs = require('fs');
const path = require('path');

async function uploadZip() {
  const zipPath = path.join(__dirname, '..', 'visual_fx_production.zip');
  console.log('Subiendo paquete comprimido a servidor Litterbox...');

  const fileBuffer = fs.readFileSync(zipPath);
  const blob = new Blob([fileBuffer], { type: 'application/zip' });

  const formData = new FormData();
  formData.append('reqtype', 'fileupload');
  formData.append('time', '72h');
  formData.append('fileToUpload', blob, 'visual_fx_production.zip');

  const res = await fetch('https://litterbox.catbox.moe/resources/internals/api.php', {
    method: 'POST',
    body: formData
  });

  const url = await res.text();
  console.log('====================================================');
  console.log('✅ URL DE DESCARGA DIRECTA DE PRODUCCIÓN:');
  console.log(url.trim());
  console.log('====================================================');
}

uploadZip().catch(console.error);
