const puppeteer = require('puppeteer');
const fs = require('fs');

async function getIframeStreams() {
  console.log('🚀 Iniciando Chrome...');
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();

  // Escuchar peticiones de video HLS / RTMP / MP4
  const detectedVideoUrls = [];
  page.on('request', req => {
    const u = req.url();
    if (u.includes('.m3u8') || u.includes('.flv') || u.includes('.mp4') || u.includes('rtmp') || u.includes('stream') || u.includes('live')) {
      console.log('🎥 SEÑAL DETECTADA:', u);
      detectedVideoUrls.push(u);
    }
  });

  console.log('🌐 Logueando en GranVideoHD...');
  await page.goto('https://www.granvideohd.com/cl/accesoooo.php', { waitUntil: 'networkidle2' });
  await page.type('input[name="usuario"]', 'leo1');
  await page.type('input[name="clave"]', '1234');
  await page.evaluate(() => {
    document.querySelector('#form_acceso').submit();
  });

  await new Promise(r => setTimeout(r, 4000));
  console.log('📍 URL tras login submit:', page.url());

  const pagesToTest = [
    'https://www.granvideohd.com/nac1.php',
    'https://www.granvideohd.com/nac2.php',
    'https://www.granvideohd.com/usa1.php',
    'https://www.granvideohd.com/usa2.php',
    'https://www.granvideohd.com/usa3.php',
    'https://www.granvideohd.com/usa4.php'
  ];

  const iframeContents = {};

  for (const url of pagesToTest) {
    try {
      console.log(`\n🔎 Visitando: ${url}`);
      await page.goto(url, { waitUntil: 'networkidle2', timeout: 10000 });
      const html = await page.content();
      iframeContents[url] = html;
      console.log(`📄 HTML de ${url} (${html.length} bytes):`);
      console.log(html.substring(0, 800));
    } catch (e) {
      console.log(`❌ Error visitando ${url}: ${e.message}`);
    }
  }

  fs.writeFileSync('iframe_analysis.json', JSON.stringify({ detectedVideoUrls, iframeContents }, null, 2));

  await browser.close();
}

getIframeStreams().catch(console.error);
