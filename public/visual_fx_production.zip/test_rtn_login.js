const puppeteer = require('puppeteer');
const fs = require('fs');

async function testRtnLogin() {
  console.log('🚀 1. Iniciando navegador Puppeteer para RTN.tv...');
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 800 });

  const capturedUrls = [];
  page.on('request', req => {
    const u = req.url();
    if (u.includes('.m3u8') || u.includes('.mpd') || u.includes('stream') || u.includes('player') || u.includes('live')) {
      if (!u.includes('google') && !u.includes('facebook') && !u.includes('analytics')) {
        capturedUrls.push(u);
      }
    }
  });

  console.log('🌐 2. Entrando a https://online.rtn.tv/...');
  await page.goto('https://online.rtn.tv/', { waitUntil: 'networkidle2' });

  // Buscar campos de usuario y contraseña
  console.log('🔑 3. Llenando credenciales RTN (Hector_mu2001@yahoo.com)...');
  const userField = await page.$('input[name="username"], input[name="user"], input[name="email"], #username, #txtUser');
  const passField = await page.$('input[name="password"], input[name="pass"], #password, #txtPass');

  if (userField && passField) {
    await userField.type('Hector_mu2001@yahoo.com');
    await passField.type('K!Z9qz$ew2SamCp');
    
    const submitBtn = await page.$('button[type="submit"], input[type="submit"], #submit, #login');
    if (submitBtn) {
      await Promise.all([
        submitBtn.click(),
        page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(e => {})
      ]);
    } else {
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(e => {});
    }
  } else {
    console.log('⚠️ No se encontraron campos de login directo en la portada. Inspeccionando HTML...');
    const pageHtml = await page.content();
    fs.writeFileSync('rtn_front.html', pageHtml);
  }

  console.log('📍 4. URL Tras Login:', page.url());
  await page.screenshot({ path: 'rtn_login_status.png' });

  // Inspeccionar elementos iFrame y enlaces
  const frameUrls = await page.evaluate(() => {
    return Array.from(document.querySelectorAll('iframe, embed, video')).map(el => el.src || el.getAttribute('src'));
  });

  console.log('📺 iFrames y Reproductores Encontrados:', frameUrls);
  console.log('🎥 URLs de Red Capturadas:', capturedUrls.slice(0, 10));

  await browser.close();
}

testRtnLogin().catch(console.error);
